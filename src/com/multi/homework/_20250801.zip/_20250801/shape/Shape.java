package com.multi.homework._20250801.shape;

public class Shape {
    String name;

    public Shape(String name) {
        this.name = name;
    }
    public void printInfo(){
        System.out.println("도형이름 :"+name);
    };
}
